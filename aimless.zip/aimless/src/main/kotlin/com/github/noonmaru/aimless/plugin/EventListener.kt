package com.github.noonmaru.aimless.plugin

import com.destroystokyo.paper.event.server.PaperServerListPingEvent
import net.md_5.bungee.api.ChatColor
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.PlayerDeathEvent
import org.bukkit.event.player.*
import org.bukkit.event.server.TabCompleteEvent
import java.awt.Color
import java.util.*
import kotlin.random.Random.Default.nextInt

class EventListener : Listener {
    @EventHandler
    fun onPlayerLogin(event: PlayerLoginEvent) {
        if (event.result == PlayerLoginEvent.Result.KICK_FULL)
            event.allow()
    }

    @EventHandler
    fun onPlayerJoin(event: PlayerJoinEvent) {
        event.joinMessage = "누군가 서버에 들어왔습니다!"

        PlayerList.update()

        val player = event.player

        }

    }

    @EventHandler
    fun onPlayerQuit(event: PlayerQuitEvent) {
        event.quitMessage = "누군가 서버를 나갔습니다!"

        PlayerList.update()
    }

    @EventHandler(ignoreCancelled = true)
    fun onTabComplete(event: TabCompleteEvent) {
        event.isCancelled = true
    }

    @EventHandler
    fun onPlayerCommandPreprocess(event: PlayerCommandPreprocessEvent) {
        event.isCancelled = true

        val message = event.message.removePrefix("/")
        Emote.emoteBy(message)?.invoke(event.player.location)
    }

    @EventHandler
    fun onPlayerDeath(event: PlayerDeathEvent) {
        event.deathMessage = "${ChatColor.of(Color(nextInt(0xFFFFFF)))}${ChatColor.BOLD}누군가 운트롤을 하면서 죽었습니다!"
    }

    @EventHandler
    fun onPaperServerListPing(event: PaperServerListPingEvent) {
        val c = Calendar.getInstance()

        event.numPlayers = c.get(Calendar.MONTH) + 1 * 100 + c.get(Calendar.DAY_OF_MONTH)
        event.maxPlayers = c.get(Calendar.YEAR) * 10000
        event.motd = "${ChatColor.of(Color(nextInt(0xFFFFFF)))}${ChatColor.BOLD}우리들의 마크 야생"
        event.playerSample.clear()
    }

    @EventHandler(ignoreCancelled = true)
    fun onPlayerKick(event: PlayerKickEvent) {
        event.isCancelled = true
    }

fun String.removeLang(): String {
    return this.replace("([a-zA-Z])|([ㄱ-힣])".toRegex(), "?")
}